package th.donut;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {

    // ---------- โครงสร้างข้อมูล ----------
    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        int page;
        List<Order> orders = new ArrayList<>();
        List<Listing> shown = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<Material> mats = new ArrayList<>();
        SpawnerData sp;
        List<List<ItemStack>> goods = new ArrayList<>();
        List<Long> prices = new ArrayList<>();
        Map<Integer, Integer> slotIdx = new HashMap<>();
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    static class Listing {
        final int id; final UUID seller; final ItemStack item; final double price; final long time;
        Listing(int id, UUID seller, ItemStack item, double price, long time) {
            this.id = id; this.seller = seller; this.item = item; this.price = price; this.time = time;
        }
    }

    static class TpaReq {
        final UUID from; final boolean here; final long expire;
        TpaReq(UUID from, boolean here, long expire) { this.from = from; this.here = here; this.expire = expire; }
    }

    static class SpawnerData {
        final String id, world; final UUID owner; final EntityType type; final int x, y, z;
        int stack = 1; long xp = 0;
        final Map<Material, Long> items = new HashMap<>();
        SpawnerData(UUID owner, EntityType type, String world, int x, int y, int z) {
            this.owner = owner; this.type = type; this.world = world; this.x = x; this.y = y; this.z = z;
            this.id = world + ":" + x + "," + y + "," + z;
        }
    }

    private final Map<String, SpawnerData> spawners = new HashMap<>();
    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Long> playSeconds = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Map<UUID, TpaReq> tpaReqs = new HashMap<>();
    private final Map<UUID, String> teamInvites = new HashMap<>();
    private int nextOrderId = 1;
    private int nextListingId = 1;
    private long keyallNext;
    private File dataFile;
    private YamlConfiguration data;

    // ---------- เปิด/ปิดปลั๊กอิน ----------
    @Override
    public void onEnable() {
        // ถ้า config เก่า (เวอร์ชันต่ำกว่า 2) ให้ย้ายไปเป็น config-old.yml แล้วสร้างใหม่
        File cf = new File(getDataFolder(), "config.yml");
        if (cf.exists() && YamlConfiguration.loadConfiguration(cf).getInt("config-version", 1) < 4) {
            File old = new File(getDataFolder(), "config-old.yml");
            if (old.exists()) old.delete();
            cf.renameTo(old);
        }
        saveDefaultConfig();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "ah", "rtp", "sethome", "home", "delhome", "homes",
                "balance", "pay", "tpa", "tphere", "tpaccept", "tpdeny", "tpauto", "settings", "nv", "team", "eco", "rules", "spawner", "shardshop", "shards")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        long siv = Math.max(1, getConfig().getLong("spawner.interval-seconds", 15)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::produceAll, siv, siv);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
    }

    @Override
    public void onDisable() { saveData(); }

    void tick() {
        long now = System.currentTimeMillis();
        if (now >= keyallNext) {
            keyall();
            keyallNext = now + keyallInterval();
        }
        long per = getConfig().getLong("shards.per-minutes", 10) * 60;
        long amt = getConfig().getLong("shards.amount", 1);
        for (Player p : Bukkit.getOnlinePlayers()) {
            long t = playSeconds.merge(p.getUniqueId(), 1L, Long::sum);
            if (per > 0 && t % per == 0) {
                shards.merge(p.getUniqueId(), amt, Long::sum);
                if (getConfig().getBoolean("shards.notify", false)) msg(p, "&dคุณได้รับ &f" + amt + " &dShards จากการเล่น!");
            }
            updateBoard(p);
        }
    }

    long keyallInterval() { return Math.max(1, getConfig().getLong("keyall.interval-minutes", 60)) * 60_000L; }

    void keyall() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            msg(p, "&9&lKEYALL! &fทุกคนได้รับรางวัลแล้ว");
            if (getConfig().getBoolean("keyall.give-armor-set", true)) giveArmorSet(p);
            for (String cmd : getConfig().getStringList("keyall.commands"))
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
    }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    void msg(CommandSender s, String m) { s.sendMessage(c(getConfig().getString("prefix", "") + m)); }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String hms(long s) { return (s / 3600) + "h " + (s % 3600 / 60) + "m " + (s % 60) + "s"; }

    static String shortTime(long s) {
        long h = s / 3600, m = s % 3600 / 60, x = s % 60;
        return h > 0 ? h + "h " + m + "m " + x + "s" : m + "m " + x + "s";
    }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setDisplayName(c(name));
        if (lore.length > 0) mt.setLore(Arrays.stream(lore).map(this::c).collect(Collectors.toList()));
        it.setItemMeta(mt);
        return it;
    }

    boolean setting(UUID id, String key, boolean def) { return data.getBoolean("settings." + id + "." + key, def); }

    void setSetting(UUID id, String key, boolean v) { data.set("settings." + id + "." + key, v); }

    List<String> names(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).collect(Collectors.toList());
    }

    List<String> mobs(String prefix) {
        return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                .filter(k -> k.startsWith(prefix.toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
    }

    void applyEnchants(ItemStack it, Collection<?> list) {
        for (Object o : list) {
            try {
                String[] a = String.valueOf(o).split(":");
                Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase(Locale.ROOT)));
                if (en != null) it.addUnsafeEnchantment(en, a.length > 1 ? Integer.parseInt(a[1]) : 1);
            } catch (Exception ignored) { }
        }
    }

    void giveArmorSet(Player p) {
        for (Material m : new Material[]{Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS}) {
            ItemStack it = new ItemStack(m);
            applyEnchants(it, getConfig().getStringList("keyall.armor-enchants"));
            give(p, it);
        }
    }

    void shardsCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length >= 3 && a[0].equalsIgnoreCase("pay")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            long amt = (long) parseAmount(a[2]);
            if (t == null || t == p || amt <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
            if (shards.getOrDefault(id, 0L) < amt) { msg(p, "&cShards ไม่พอ"); return; }
            shards.merge(id, -amt, Long::sum);
            shards.merge(t.getUniqueId(), amt, Long::sum);
            msg(p, "&aโอน &d" + fmt(amt) + " Shards &aให้ " + t.getName());
            msg(t, "&aได้รับ &d" + fmt(amt) + " Shards &aจาก " + p.getName());
            return;
        }
        msg(p, "&dShards ของคุณ: &f" + fmt(shards.getOrDefault(id, 0L)) + " &7| /shardshop เปิดร้านค้า | /shards pay <ผู้เล่น> <จำนวน>");
    }

    void openShardShop(Player p) {
        Gui g = new Gui("shardshop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shardshop.title", "&5&lShard Shop")));
        int auto = 10;
        for (Map<?, ?> m : getConfig().getMapList("shardshop.items")) {
            try {
                List<String> ench = new ArrayList<>();
                if (m.get("enchants") instanceof List<?> el) for (Object o : el) ench.add(String.valueOf(o));
                List<ItemStack> goods = new ArrayList<>();
                ItemStack display;
                Object armorSet = m.get("armor-set");
                if (armorSet != null) {
                    for (String part : List.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS")) {
                        Material pm = Material.matchMaterial(String.valueOf(armorSet).toUpperCase(Locale.ROOT) + "_" + part);
                        if (pm == null) continue;
                        ItemStack pi = new ItemStack(pm);
                        applyEnchants(pi, ench);
                        goods.add(pi);
                    }
                    if (goods.isEmpty()) continue;
                    display = goods.get(goods.size() > 1 ? 1 : 0).clone();
                } else {
                    Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                    if (mat == null) continue;
                    int amt = m.get("amount") instanceof Number nn ? nn.intValue() : 1;
                    ItemStack gi = new ItemStack(mat, Math.max(1, amt));
                    applyEnchants(gi, ench);
                    goods.add(gi);
                    display = gi.clone();
                }
                long price = ((Number) m.get("price")).longValue();
                int slot = m.get("slot") instanceof Number sn ? sn.intValue() : auto++;
                if (slot < 0 || slot >= 54) continue;
                ItemMeta mt = display.getItemMeta();
                if (m.get("name") != null) mt.setDisplayName(c(String.valueOf(m.get("name"))));
                List<String> lore = new ArrayList<>();
                if (armorSet != null) lore.add(c("&7ได้ครบ 4 ชิ้น"));
                lore.add(c("&7ราคา: &d" + fmt(price) + " Shards"));
                lore.add(c("&eคลิกเพื่อซื้อ"));
                mt.setLore(lore);
                display.setItemMeta(mt);
                g.slotIdx.put(slot, g.goods.size());
                g.goods.add(goods);
                g.prices.add(price);
                g.inv.setItem(slot, display);
            } catch (Exception ignored) { }
        }
        g.inv.setItem(49, item(Material.NETHER_STAR, "&dShards: &f" + fmt(shards.getOrDefault(p.getUniqueId(), 0L)), "&7เล่นเพื่อสะสม Shards"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    double sellPrice(Material m) { return getConfig().getDouble("sell." + m.name(), getConfig().getDouble("sell-default", 1)); }

    // ---------- เก็บข้อมูล ----------
    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection sh = data.getConfigurationSection("shards");
        if (sh != null) for (String k : sh.getKeys(false)) shards.put(UUID.fromString(k), sh.getLong(k));
        ConfigurationSection pt = data.getConfigurationSection("playtime");
        if (pt != null) for (String k : pt.getKeys(false)) playSeconds.put(UUID.fromString(k), pt.getLong(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            orders.add(new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price")));
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection as = data.getConfigurationSection("auctions");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection s = as.getConfigurationSection(k);
            ItemStack it = s.getItemStack("item");
            if (it == null) continue;
            int id = Integer.parseInt(k);
            listings.add(new Listing(id, UUID.fromString(s.getString("seller")), it, s.getDouble("price"), s.getLong("time")));
            nextListingId = Math.max(nextListingId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
        ConfigurationSection sps = data.getConfigurationSection("spawners");
        if (sps != null) for (String k : sps.getKeys(false)) {
            ConfigurationSection sc = sps.getConfigurationSection(k);
            try {
                SpawnerData sd = new SpawnerData(UUID.fromString(sc.getString("owner")), EntityType.valueOf(sc.getString("type")),
                        sc.getString("world"), sc.getInt("x"), sc.getInt("y"), sc.getInt("z"));
                sd.stack = Math.max(1, sc.getInt("stack", 1));
                sd.xp = sc.getLong("xp");
                ConfigurationSection its = sc.getConfigurationSection("items");
                if (its != null) for (String mk : its.getKeys(false)) {
                    Material mm = Material.matchMaterial(mk);
                    if (mm != null) sd.items.put(mm, its.getLong(mk));
                }
                spawners.put(sd.id, sd);
            } catch (Exception ex) { getLogger().warning("bad spawner entry " + k); }
        }
        keyallNext = data.getLong("keyall.next", 0);
        if (keyallNext <= System.currentTimeMillis()) keyallNext = System.currentTimeMillis() + keyallInterval();
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("shards", null);
        shards.forEach((k, v) -> data.set("shards." + k, v));
        data.set("playtime", null);
        playSeconds.forEach((k, v) -> data.set("playtime." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "price", o.price);
        }
        data.set("auctions", null);
        for (Listing l : listings) {
            String p = "auctions." + l.id + ".";
            data.set(p + "seller", l.seller.toString());
            data.set(p + "item", l.item);
            data.set(p + "price", l.price);
            data.set(p + "time", l.time);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        data.set("spawners", null);
        int si = 0;
        for (SpawnerData sd : spawners.values()) {
            String b = "spawners." + (si++) + ".";
            data.set(b + "world", sd.world);
            data.set(b + "x", sd.x); data.set(b + "y", sd.y); data.set(b + "z", sd.z);
            data.set(b + "owner", sd.owner.toString());
            data.set(b + "type", sd.type.name());
            data.set(b + "stack", sd.stack);
            data.set(b + "xp", sd.xp);
            for (Map.Entry<Material, Long> en : sd.items.entrySet()) data.set(b + "items." + en.getKey().name(), en.getValue());
        }
        data.set("keyall.next", keyallNext);
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    String teamName(UUID id) {
        String key = data.getString("playerTeam." + id);
        if (key == null) return "none";
        return data.getString("teams." + key + ".name", "none");
    }

    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, c(getConfig().getString("scoreboard.title", "DONUT SMP")));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "§" + Integer.toHexString(i) + "§r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        UUID id = p.getUniqueId();
        if (!setting(id, "scoreboard", true)) {
            if (p.getScoreboard().getObjective("donut") != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            return;
        }
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { setupBoard(p); return; }
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        long keyLeft = Math.max(0, (keyallNext - System.currentTimeMillis()) / 1000);
        for (int i = 0; i < Math.min(15, lines.size()); i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String line = lines.get(i)
                    .replace("{money}", fmt(bal(id)))
                    .replace("{shards}", fmt(shards.getOrDefault(id, 0L)))
                    .replace("{kills}", String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS)))
                    .replace("{deaths}", String.valueOf(p.getStatistic(Statistic.DEATHS)))
                    .replace("{keyall}", shortTime(keyLeft))
                    .replace("{playtime}", hms(playSeconds.getOrDefault(id, 0L)))
                    .replace("{team}", teamName(id))
                    .replace("{player}", p.getName())
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            t.setPrefix(c(line));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        setupBoard(p);
    }

    // ---------- คำสั่ง ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("eco")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length < 3) { msg(s, "&e/eco <give|set|take> <player> [money|shards|keyall] <amount>"); return true; }
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            UUID tid = t.getUniqueId();
            String kind = "money";
            String amtStr = a[2];
            if (a.length >= 4) { kind = a[2].toLowerCase(Locale.ROOT); amtStr = a[3]; }
            double amt = parseAmount(amtStr);
            if (amt < 0) { msg(s, "&cจำนวนไม่ถูกต้อง"); return true; }
            String act = a[0].toLowerCase(Locale.ROOT);
            switch (kind) {
                case "money" -> {
                    switch (act) {
                        case "give" -> add(tid, amt);
                        case "take" -> add(tid, -amt);
                        case "set" -> money.put(tid, amt);
                        default -> { msg(s, "&cใช้ give/set/take"); return true; }
                    }
                    msg(s, "&aMoney ของ " + a[1] + " ตอนนี้ $" + fmt(bal(tid)));
                }
                case "shards" -> {
                    long v = (long) amt;
                    long cur = shards.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> shards.put(tid, cur + v);
                        case "take" -> shards.put(tid, Math.max(0, cur - v));
                        case "set" -> shards.put(tid, v);
                        default -> { msg(s, "&cใช้ give/set/take"); return true; }
                    }
                    msg(s, "&dShards ของ " + a[1] + " ตอนนี้ " + fmt(shards.getOrDefault(tid, 0L)));
                }
                case "keyall" -> {
                    Player tp = Bukkit.getPlayer(tid);
                    if (!act.equals("give")) { msg(s, "&cKeyall ใช้ได้เฉพาะ give"); return true; }
                    if (tp == null) { msg(s, "&cผู้เล่นต้องออนไลน์"); return true; }
                    int sets = (int) Math.max(1, Math.min(64, amt));
                    for (int i = 0; i < sets; i++) giveArmorSet(tp);
                    msg(s, "&aให้ชุดเกราะเพชร (Keyall) x" + sets + " แก่ " + tp.getName());
                }
                default -> msg(s, "&cชนิดต้องเป็น money / shards / keyall");
            }
            return true;
        }

        if (n.equals("spawner")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length >= 2 && a[0].equalsIgnoreCase("fill")) {
                if (!(s instanceof Player fp)) { msg(s, "&cเฉพาะผู้เล่น"); return true; }
                EntityType ft;
                try { ft = EntityType.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (Exception ex) { ft = null; }
                if (ft == null) { msg(s, "&cไม่พบชนิดมอนสเตอร์"); return true; }
                ItemStack[] cont = fp.getInventory().getStorageContents();
                int filled = 0;
                for (int i = 0; i < cont.length; i++) {
                    if (cont[i] == null || cont[i].getType().isAir()) { cont[i] = spawnerItem(ft, 64); filled++; }
                }
                fp.getInventory().setStorageContents(cont);
                msg(s, "&aเสก " + nice(ft) + " Spawner x64 ลงช่องว่าง " + filled + " ช่อง");
                return true;
            }
            if (a.length < 3 || !a[0].equalsIgnoreCase("give")) { msg(s, "&e/spawner give <player> <mob> [amount] | /spawner fill <mob>"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            EntityType et;
            try { et = EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); } catch (Exception ex) { et = null; }
            if (t == null || et == null) { msg(s, "&cไม่พบผู้เล่นหรือชนิดมอนสเตอร์"); return true; }
            int amt = 1;
            if (a.length > 3) { try { amt = Math.max(1, Math.min(64, Integer.parseInt(a[3]))); } catch (NumberFormatException ex) { amt = 1; } }
            give(t, spawnerItem(et, amt));
            msg(s, "&aให้ " + nice(et) + " Spawner x" + amt + " แก่ " + t.getName());
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("เฉพาะผู้เล่นเท่านั้น"); return true; }
        UUID id = p.getUniqueId();

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "ah" -> ahCmd(p, a);
            case "rtp" -> rtpCmd(p, a);
            case "balance" -> msg(p, "&eเงินของคุณ: &a$" + fmt(bal(id)));
            case "pay" -> pay(p, a);
            case "tpa" -> tpaCmd(p, a, false);
            case "tphere" -> tpaCmd(p, a, true);
            case "tpaccept" -> tpRespond(p, true);
            case "tpdeny" -> tpRespond(p, false);
            case "tpauto" -> {
                boolean v = !setting(id, "tpauto", false);
                setSetting(id, "tpauto", v);
                msg(p, "&eรับ TPA อัตโนมัติ: " + (v ? "&aเปิด" : "&cปิด"));
            }
            case "settings" -> openSettings(p);
            case "nv" -> {
                if (p.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
                    p.removePotionEffect(PotionEffectType.NIGHT_VISION);
                    msg(p, "&eมองเห็นกลางคืน: &cปิด");
                } else {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
                    msg(p, "&eมองเห็นกลางคืน: &aเปิด");
                }
            }
            case "team" -> teamCmd(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                String base = "homes." + id;
                ConfigurationSection hs = data.getConfigurationSection(base);
                int count = hs == null ? 0 : hs.getKeys(false).size();
                boolean exists = hs != null && hs.contains(name);
                if (!exists && count >= getConfig().getInt("homes.max", 3)) { msg(p, "&cคุณตั้งบ้านได้สูงสุด " + getConfig().getInt("homes.max", 3) + " หลัง"); return true; }
                data.set(base + "." + name, p.getLocation());
                msg(p, "&aตั้งบ้าน &e" + name + " &aแล้ว");
            }
            case "home" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                Location l = data.getLocation("homes." + id + "." + name);
                if (l == null) { msg(p, "&cไม่พบบ้านชื่อ " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aวาปไปบ้าน &e" + name);
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + id + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cไม่พบบ้านนี้"); return true; }
                data.set(path, null);
                msg(p, "&aลบบ้านแล้ว");
            }
            case "homes" -> openHomes(p);
            case "rules" -> openRules(p);
            case "shardshop" -> openShardShop(p);
            case "shards" -> shardsCmd(p, a);
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (amt <= 0) { msg(p, "&cจำนวนไม่ถูกต้อง"); return; }
        if (!setting(t.getUniqueId(), "pay", true)) { msg(p, "&cผู้เล่นนี้ปิดรับเงินโอน"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cเงินไม่พอ"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aโอน $" + fmt(amt) + " ให้ " + t.getName());
        msg(t, "&aได้รับ $" + fmt(amt) + " จาก " + p.getName());
    }

    // ---------- TPA ----------
    void tpaCmd(Player p, String[] a, boolean here) {
        if (a.length < 1) { msg(p, "&e/" + (here ? "tphere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (!setting(t.getUniqueId(), "tpa", true)) { msg(p, "&cผู้เล่นนี้ปิดรับคำขอวาป"); return; }
        if (setting(t.getUniqueId(), "tpauto", false)) { doTp(p, t, here); return; }
        tpaReqs.put(t.getUniqueId(), new TpaReq(p.getUniqueId(), here, System.currentTimeMillis() + 60_000));
        msg(p, "&aส่งคำขอไปยัง &e" + t.getName() + " &aแล้ว (หมดอายุใน 60 วินาที)");
        msg(t, "&e" + p.getName() + " &fขอ" + (here ? "ให้คุณวาปไปหาเขา" : "วาปมาหาคุณ") + " &7- พิมพ์ &a/tpaccept &7หรือ &c/tpdeny");
    }

    void doTp(Player requester, Player target, boolean here) {
        if (here) {
            target.teleportAsync(requester.getLocation());
            msg(target, "&aวาปไปหา &e" + requester.getName());
            msg(requester, "&e" + target.getName() + " &aวาปมาหาคุณแล้ว");
        } else {
            requester.teleportAsync(target.getLocation());
            msg(requester, "&aวาปไปหา &e" + target.getName());
            msg(target, "&e" + requester.getName() + " &aวาปมาหาคุณแล้ว");
        }
    }

    void tpRespond(Player p, boolean accept) {
        TpaReq r = tpaReqs.remove(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { msg(p, "&cไม่มีคำขอวาปที่รออยู่"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { msg(p, "&cผู้ขอออฟไลน์แล้ว"); return; }
        if (!accept) {
            msg(p, "&cปฏิเสธคำขอแล้ว");
            msg(from, "&c" + p.getName() + " ปฏิเสธคำขอวาปของคุณ");
            return;
        }
        doTp(from, p, r.here);
    }

    // ---------- /settings ----------
    private static final String[][] SETTINGS = {
            {"scoreboard", "แสดงสกอร์บอร์ด", "true", "OAK_SIGN"},
            {"tpauto", "รับ TPA อัตโนมัติ", "false", "ENDER_PEARL"},
            {"tpa", "รับคำขอ TPA/TPHERE", "true", "COMPASS"},
            {"pay", "รับเงินโอน (/pay)", "true", "GOLD_INGOT"}};
    private static final int[] SETTING_SLOTS = {10, 12, 14, 16};

    void fill(Inventory inv, Material m) {
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, item(m, " "));
    }

    void openSettings(Player p) {
        Gui g = new Gui("settings");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lSettings"));
        for (int i = 0; i < SETTINGS.length; i++) {
            boolean on = setting(p.getUniqueId(), SETTINGS[i][0], Boolean.parseBoolean(SETTINGS[i][2]));
            g.inv.setItem(SETTING_SLOTS[i], item(Material.valueOf(SETTINGS[i][3]), "&f" + SETTINGS[i][1],
                    "", on ? "&a✔ เปิดอยู่" : "&c✘ ปิดอยู่", "", "&eคลิกเพื่อสลับ"));
            g.inv.setItem(SETTING_SLOTS[i] + 9, item(on ? Material.LIME_DYE : Material.GRAY_DYE,
                    on ? "&aเปิด" : "&cปิด", "&7คลิกเพื่อสลับ"));
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- /homes GUI ----------
    void openHomes(Player p) {
        Gui g = new Gui("homes");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lHomes"));
        ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
        if (hs != null) g.names.addAll(new TreeSet<>(hs.getKeys(false)));
        int max = Math.min(7, getConfig().getInt("homes.max", 3));
        for (int i = 0; i < max; i++) {
            if (i < g.names.size()) {
                String nm = g.names.get(i);
                Location l = data.getLocation("homes." + p.getUniqueId() + "." + nm);
                String loc = (l != null && l.getWorld() != null)
                        ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
                g.inv.setItem(10 + i, item(Material.RED_BED, "&a" + nm, "&7" + loc, "", "&eคลิกซ้าย = วาป", "&cShift+คลิกขวา = ลบ"));
            } else {
                g.inv.setItem(10 + i, item(Material.LIGHT_GRAY_BED, "&7ช่องบ้านว่าง", "&eคลิกเพื่อตั้งบ้านที่ตำแหน่งนี้"));
            }
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    String nextHomeName(UUID id) {
        int n = 1;
        while (data.contains("homes." + id + ".home" + n)) n++;
        return "home" + n;
    }

    // ---------- /rules GUI ----------
    void openRules(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("rules-gui.size", 27) / 9 * 9));
        Gui g = new Gui("rules");
        g.inv = Bukkit.createInventory(g, size, c(getConfig().getString("rules-gui.title", "&8Rules")));
        for (Map<?, ?> m : getConfig().getMapList("rules-gui.items")) {
            try {
                int slot = ((Number) m.get("slot")).intValue();
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || slot < 0 || slot >= size) continue;
                List<String> lore = new ArrayList<>();
                Object lo = m.get("lore");
                if (lo instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                g.inv.setItem(slot, item(mat, String.valueOf(m.get("name")), lore.toArray(new String[0])));
            } catch (Exception ignored) { }
        }
        Material fm = Material.matchMaterial(getConfig().getString("rules-gui.filler", "BLACK_STAINED_GLASS_PANE"));
        if (fm != null) fill(g.inv, fm);
        p.openInventory(g.inv);
    }

    // ---------- Virtual Spawner ----------
    String nice(EntityType t) {
        String n = t.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    String key(Block b) { return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ(); }

    ItemStack spawnerItem(EntityType t, int amt) {
        ItemStack it = new ItemStack(Material.SPAWNER, amt);
        BlockStateMeta bm = (BlockStateMeta) it.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) bm.getBlockState();
        cs.setSpawnedType(t);
        bm.setBlockState(cs);
        bm.setDisplayName(c("&6" + nice(t) + " Spawner"));
        bm.setLore(List.of(c("&7วางแล้วคลิกขวามือเปล่าเพื่อเปิด"), c("&7คลิกขวาด้วยสปอว์นเนอร์ชนิดเดียวกันเพื่อซ้อน")));
        it.setItemMeta(bm);
        return it;
    }

    EntityType spawnerType(ItemStack it) {
        if (it == null || it.getType() != Material.SPAWNER) return null;
        if (it.getItemMeta() instanceof BlockStateMeta bm && bm.getBlockState() instanceof CreatureSpawner cs) return cs.getSpawnedType();
        return null;
    }

    boolean canUse(Player p, SpawnerData sd) {
        return !getConfig().getBoolean("spawner.owner-only", false) || sd.owner.equals(p.getUniqueId()) || p.hasPermission("donutsmp.admin");
    }

    @EventHandler
    public void onSpawnerPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.SPAWNER) return;
        EntityType t = spawnerType(e.getItemInHand());
        if (t == null) return;
        Block b = e.getBlockPlaced();
        SpawnerData sd = new SpawnerData(e.getPlayer().getUniqueId(), t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        spawners.put(sd.id, sd);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0); // ปิดการเกิดมอนสเตอร์จริง ใช้ระบบเสมือนแทน
            cs.update();
        }
        msg(e.getPlayer(), "&aวางสปอว์นเนอร์ &e" + nice(t) + " &7(คลิกขวามือเปล่าเพื่อเปิด)");
    }

    @EventHandler
    public void onSpawnerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean empty = hand == null || hand.getType().isAir();
        EntityType ht = spawnerType(hand);
        if (!empty && ht == null) return;
        if (!empty && p.isSneaking()) return;
        e.setCancelled(true);
        if (!canUse(p, sd)) { msg(p, "&cสปอว์นเนอร์นี้เป็นของคนอื่น"); return; }
        if (ht != null) {
            if (ht != sd.type) { msg(p, "&cชนิดสปอว์นเนอร์ไม่ตรงกัน"); return; }
            if (sd.stack + 1 > getConfig().getInt("spawner.max-stack", 1000)) { msg(p, "&cซ้อนได้สูงสุดแล้ว"); return; }
            sd.stack++;
            hand.setAmount(hand.getAmount() - 1);
            msg(p, "&aซ้อนสปอว์นเนอร์ ตอนนี้ &ex" + sd.stack);
            return;
        }
        openSpawner(p, sd, 0);
    }

    @EventHandler
    public void onSpawnerBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        if (!canUse(p, sd)) { e.setCancelled(true); msg(p, "&cสปอว์นเนอร์นี้เป็นของคนอื่น"); return; }
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (getConfig().getBoolean("spawner.require-silk-touch", true)
                && !tool.containsEnchantment(Enchantment.SILK_TOUCH) && !p.hasPermission("donutsmp.admin")) {
            e.setCancelled(true);
            msg(p, "&cต้องใช้เครื่องมือที่มี Silk Touch");
            return;
        }
        e.setExpToDrop(0);
        e.setDropItems(false);
        give(p, spawnerItem(sd.type, 1));
        if (sd.stack > 1) {
            sd.stack--;
            e.setCancelled(true);
            msg(p, "&eเก็บสปอว์นเนอร์ 1 อัน เหลือ &fx" + sd.stack);
        } else {
            spawners.remove(sd.id);
            msg(p, "&eเก็บสปอว์นเนอร์แล้ว (ของที่ยังไม่ได้เก็บในสปอว์นเนอร์จะหายไป)");
        }
    }

    @EventHandler
    public void onSpawnerExplode(EntityExplodeEvent e) {
        if (getConfig().getBoolean("spawner.explosion-protect", true))
            e.blockList().removeIf(b -> b.getType() == Material.SPAWNER && spawners.containsKey(key(b)));
    }

    void produceAll() {
        double dist = getConfig().getDouble("spawner.activation-distance", 16);
        double d2 = dist * dist;
        for (SpawnerData sd : spawners.values()) {
            World w = Bukkit.getWorld(sd.world);
            if (w == null) continue;
            boolean near = false;
            for (Player p : w.getPlayers()) {
                double dx = p.getX() - sd.x, dy = p.getY() - sd.y, dz = p.getZ() - sd.z;
                if (dx * dx + dy * dy + dz * dz <= d2) { near = true; break; }
            }
            if (near) produce(sd);
        }
    }

    void produce(SpawnerData sd) {
        long cap = getConfig().getLong("spawner.max-items", 50000);
        long total = sd.items.values().stream().mapToLong(Long::longValue).sum();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]) * sd.stack, hi = Long.parseLong(range[1]) * sd.stack;
                long amt = lo >= hi ? lo : r.nextLong(lo, hi + 1);
                amt = Math.min(amt, Math.max(0, cap - total));
                if (amt <= 0) continue;
                sd.items.merge(m, amt, Long::sum);
                total += amt;
            } catch (Exception ignored) { }
        }
        long maxXp = getConfig().getLong("spawner.max-xp", 100000);
        sd.xp = Math.min(maxXp, sd.xp + getConfig().getLong("spawner.xp-per-cycle", 5) * sd.stack);
    }

    long takeFromSpawner(Player p, SpawnerData sd, Material m, long want) {
        long have = sd.items.getOrDefault(m, 0L);
        want = Math.min(want, have);
        long given = 0;
        while (given < want) {
            int st = (int) Math.min(want - given, m.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        if (given > 0) {
            long rem = have - given;
            if (rem <= 0) sd.items.remove(m); else sd.items.put(m, rem);
        }
        return given;
    }

    void openSpawner(Player p, SpawnerData sd, int page) {
        List<Material> mats = new ArrayList<>(sd.items.keySet());
        mats.removeIf(m -> sd.items.getOrDefault(m, 0L) <= 0);
        mats.sort(Comparator.comparing(Enum::name));
        int pages = Math.max(1, (mats.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("spawner");
        g.sp = sd;
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8" + nice(sd.type) + " Spawner x" + sd.stack + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(mats.size(), page * 45 + 45); i++) {
            Material m = mats.get(i);
            long n = sd.items.get(m);
            ItemStack it = new ItemStack(m, (int) Math.min(n, m.getMaxStackSize()));
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7เก็บอยู่: &f" + fmt(n)), c("&7มูลค่า: &a$" + fmt(n * sellPrice(m))),
                    c("&eคลิกซ้าย = เอา 1 สแต็ก"), c("&eShift+คลิก = เอาทั้งหมด")));
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        long totalValue = 0;
        for (Map.Entry<Material, Long> en : sd.items.entrySet()) totalValue += (long) (en.getValue() * sellPrice(en.getKey()));
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(47, item(Material.GOLD_INGOT, "&6ขายทั้งหมด", "&7มูลค่ารวม: &a$" + fmt(totalValue), "&eคลิกเพื่อขาย"));
        g.inv.setItem(49, item(Material.EXPERIENCE_BOTTLE, "&aXP: &f" + fmt(sd.xp), "&eคลิกเพื่อรับ XP"));
        g.inv.setItem(51, item(Material.CHEST, "&bเอาของในหน้านี้ทั้งหมด", "&7ของจะเข้ากระเป๋า"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- Team ----------
    void teamCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { msg(p, "&e/team create <ชื่อ> | invite <ผู้เล่น> | accept | leave | info"); return; }
        String cur = data.getString("playerTeam." + id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_]{2,12}")) { msg(p, "&e/team create <ชื่อ> &7(A-Z 0-9 _ ยาว 2-12 ตัว)"); return; }
                String key = a[1].toLowerCase(Locale.ROOT);
                if (data.contains("teams." + key)) { msg(p, "&cชื่อทีมนี้ถูกใช้แล้ว"); return; }
                data.set("teams." + key + ".name", a[1]);
                data.set("teams." + key + ".leader", id.toString());
                data.set("teams." + key + ".members", new ArrayList<>(List.of(id.toString())));
                data.set("playerTeam." + id, key);
                msg(p, "&aสร้างทีม &e" + a[1] + " &aแล้ว");
            }
            case "invite" -> {
                if (cur == null) { msg(p, "&cคุณยังไม่มีทีม"); return; }
                if (a.length < 2) { msg(p, "&e/team invite <ผู้เล่น>"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
                if (data.getString("playerTeam." + t.getUniqueId()) != null) { msg(p, "&cผู้เล่นนี้มีทีมแล้ว"); return; }
                teamInvites.put(t.getUniqueId(), cur);
                msg(p, "&aเชิญ &e" + t.getName() + " &aแล้ว");
                msg(t, "&e" + p.getName() + " &fเชิญคุณเข้าทีม &e" + teamName(id) + " &7- พิมพ์ &a/team accept");
            }
            case "accept" -> {
                String key = teamInvites.remove(id);
                if (key == null || !data.contains("teams." + key)) { msg(p, "&cไม่มีคำเชิญ"); return; }
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                List<String> members = data.getStringList("teams." + key + ".members");
                if (members.size() >= getConfig().getInt("team.max-members", 5)) { msg(p, "&cทีมเต็มแล้ว"); return; }
                members.add(id.toString());
                data.set("teams." + key + ".members", members);
                data.set("playerTeam." + id, key);
                msg(p, "&aเข้าร่วมทีม &e" + data.getString("teams." + key + ".name"));
            }
            case "leave" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                List<String> members = data.getStringList("teams." + cur + ".members");
                if (id.toString().equals(data.getString("teams." + cur + ".leader"))) {
                    for (String m : members) data.set("playerTeam." + m, null);
                    data.set("teams." + cur, null);
                    msg(p, "&eคุณเป็นหัวหน้า ทีมถูกยุบแล้ว");
                } else {
                    members.remove(id.toString());
                    data.set("teams." + cur + ".members", members);
                    data.set("playerTeam." + id, null);
                    msg(p, "&eออกจากทีมแล้ว");
                }
            }
            case "info" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                String names = data.getStringList("teams." + cur + ".members").stream()
                        .map(u -> Optional.ofNullable(Bukkit.getOfflinePlayer(UUID.fromString(u)).getName()).orElse("?"))
                        .collect(Collectors.joining(", "));
                msg(p, "&eทีม &f" + teamName(id) + " &7| สมาชิก: &f" + names);
            }
            default -> msg(p, "&e/team create | invite | accept | leave | info");
        }
    }

    // ---------- /shop ----------
    void openShop(Player p) {
        Gui g = new Gui("shop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-title")));
        ConfigurationSection s = getConfig().getConfigurationSection("shop");
        if (s != null) for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m == null || !m.isItem()) continue;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&7ราคา: &a$" + fmt(s.getDouble(key)) + " &7/ชิ้น"), c("&eคลิกซ้าย = ซื้อ 1"), c("&eShift+คลิก = ซื้อ 64")));
            it.setItemMeta(meta);
            g.inv.addItem(it);
        }
        g.inv.setItem(53, item(Material.DIAMOND_CHESTPLATE, "&bชุดเกราะเพชรครบชุด (Keyall Set)",
                "&7ราคา: &a$" + fmt(getConfig().getDouble("shop-sets.diamond-armor-set", 25000)),
                "&7ได้ครบ 4 ชิ้น", "&eคลิกเพื่อซื้อ"));
        p.openInventory(g.inv);
    }

    // ---------- /sell (ขายได้ทุกอย่าง) ----------
    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        p.openInventory(g.inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g) || !g.type.equals("sell")) return;
        Player p = (Player) e.getPlayer();
        double total = 0;
        int sold = 0;
        for (ItemStack it : e.getInventory().getContents()) {
            if (it == null || it.getType().isAir()) continue;
            double price = sellPrice(it.getType());
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
        }
        e.getInventory().clear();
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aขาย " + sold + " ชิ้น ได้เงิน &e$" + fmt(total));
        }
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price ต่อชิ้น>"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || amt <= 0 || price <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
                double cost = amt * price;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, amt, price));
                msg(p, "&aสร้างออเดอร์รับซื้อ " + m.name() + " x" + amt + " ราคา $" + fmt(price) + "/ชิ้น");
            }
            case "claim" -> {
                Map<String, Integer> map = claims.remove(p.getUniqueId());
                if (map == null || map.isEmpty()) { msg(p, "&cไม่มีของให้รับ"); return; }
                map.forEach((mat, n) -> {
                    Material m = Material.matchMaterial(mat);
                    if (m == null) return;
                    int left = n;
                    while (left > 0) {
                        int st = Math.min(left, m.getMaxStackSize());
                        give(p, new ItemStack(m, st));
                        left -= st;
                    }
                });
                msg(p, "&aรับของจากออเดอร์แล้ว");
            }
            default -> openOrders(p);
        }
    }

    void openOrders(Player p) {
        Gui g = new Gui("orders");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("order-title")));
        for (Order o : orders) {
            if (g.orders.size() >= 54) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            List<String> lore = new ArrayList<>(List.of(
                    c("&7ผู้สั่ง: &f" + owner),
                    c("&7ต้องการอีก: &f" + o.left),
                    c("&7ราคาต่อชิ้น: &a$" + fmt(o.price)),
                    c("&aคลิกซ้าย = ส่งของให้ออเดอร์นี้")));
            if (o.owner.equals(p.getUniqueId())) lore.add(c("&cคลิกขวา = ยกเลิก (คืนเงิน)"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        p.openInventory(g.inv);
    }

    void fillOrder(Player p, Order o) {
        if (o.owner.equals(p.getUniqueId())) { msg(p, "&cส่งของให้ออเดอร์ตัวเองไม่ได้"); return; }
        ItemStack[] cs = p.getInventory().getStorageContents();
        int have = 0;
        for (ItemStack it : cs) if (it != null && it.getType() == o.mat && !it.hasItemMeta()) have += it.getAmount();
        int n = Math.min(have, o.left);
        if (n <= 0) { msg(p, "&cคุณไม่มี " + o.mat.name()); return; }
        int rem = n;
        for (int i = 0; i < cs.length && rem > 0; i++) {
            ItemStack it = cs[i];
            if (it == null || it.getType() != o.mat || it.hasItemMeta()) continue;
            int t = Math.min(rem, it.getAmount());
            if (t == it.getAmount()) cs[i] = null; else it.setAmount(it.getAmount() - t);
            rem -= t;
        }
        p.getInventory().setStorageContents(cs);
        double pay = n * o.price;
        add(p.getUniqueId(), pay);
        claims.computeIfAbsent(o.owner, k -> new HashMap<>()).merge(o.mat.name(), n, Integer::sum);
        o.left -= n;
        if (o.left <= 0) orders.remove(o);
        msg(p, "&aส่ง " + n + " ชิ้น ได้เงิน &e$" + fmt(pay));
        Player owner = Bukkit.getPlayer(o.owner);
        if (owner != null) msg(owner, "&aมีคนส่ง " + o.mat.name() + " x" + n + " ให้ออเดอร์ของคุณ! พิมพ์ &e/order claim");
    }

    // ---------- /ah ----------
    void ahCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) {
            if (a.length < 2) { msg(p, "&e/ah sell <ราคา> &7(ถือของที่จะขายไว้ในมือ)"); return; }
            double price = parseAmount(a[1]);
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (price <= 0) { msg(p, "&cราคาไม่ถูกต้อง"); return; }
            if (hand == null || hand.getType().isAir()) { msg(p, "&cต้องถือของที่จะขายไว้ในมือ"); return; }
            long mine = listings.stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
            if (mine >= getConfig().getInt("ah.max-listings", 10)) { msg(p, "&cลงขายได้สูงสุด " + getConfig().getInt("ah.max-listings", 10) + " รายการ"); return; }
            listings.add(new Listing(nextListingId++, p.getUniqueId(), hand.clone(), price, System.currentTimeMillis()));
            p.getInventory().setItemInMainHand(null);
            msg(p, "&aลงขาย &e" + hand.getType().name() + " x" + hand.getAmount() + " &aราคา &e$" + fmt(price));
            return;
        }
        openAh(p, 0);
    }

    void openAh(Player p, int page) {
        List<Listing> sorted = new ArrayList<>(listings);
        sorted.sort((x, y) -> Long.compare(y.time, x.time));
        int pages = Math.max(1, (sorted.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("ah");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&6&lAuction House &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(sorted.size(), page * 45 + 45); i++) {
            Listing l = sorted.get(i);
            ItemStack d = l.item.clone();
            ItemMeta m = d.getItemMeta();
            List<String> lore = m.hasLore() && m.getLore() != null ? new ArrayList<>(m.getLore()) : new ArrayList<>();
            lore.add(c("&8──────────"));
            lore.add(c("&7ราคา: &a$" + fmt(l.price)));
            lore.add(c("&7ผู้ขาย: &f" + Optional.ofNullable(Bukkit.getOfflinePlayer(l.seller).getName()).orElse("?")));
            lore.add(c(l.seller.equals(p.getUniqueId()) ? "&cคลิกขวา = ยกเลิกการขาย" : "&aคลิกซ้าย = ซื้อ"));
            m.setLore(lore);
            d.setItemMeta(m);
            g.inv.setItem(g.shown.size(), d);
            g.shown.add(l);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(49, item(Material.PAPER, "&6วิธีลงขาย", "&7ถือของไว้ในมือแล้วพิมพ์", "&f/ah sell <ราคา>"));
        p.openInventory(g.inv);
    }

    void buyListing(Player p, Listing l) {
        if (l.seller.equals(p.getUniqueId())) { msg(p, "&cซื้อของตัวเองไม่ได้"); return; }
        if (!take(p.getUniqueId(), l.price)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(l.price) + ")"); return; }
        listings.remove(l);
        add(l.seller, l.price);
        give(p, l.item.clone());
        msg(p, "&aซื้อ " + l.item.getType().name() + " x" + l.item.getAmount() + " ราคา &e$" + fmt(l.price));
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) msg(seller, "&a" + p.getName() + " ซื้อ " + l.item.getType().name() + " ของคุณ ได้เงิน &e$" + fmt(l.price));
    }

    // ---------- คลิก GUI ----------
    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof Gui g && !g.type.equals("sell")) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) return; // ให้วางของได้อิสระ
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        Player p = (Player) e.getWhoClicked();
        int slot = e.getSlot();

        switch (g.type) {
            case "shop" -> {
                if (slot == 53 && it.getType() == Material.DIAMOND_CHESTPLATE) {
                    double setPrice = getConfig().getDouble("shop-sets.diamond-armor-set", 25000);
                    if (!take(p.getUniqueId(), setPrice)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(setPrice) + ")"); return; }
                    giveArmorSet(p);
                    msg(p, "&aซื้อชุดเกราะเพชรครบชุด ราคา $" + fmt(setPrice));
                    return;
                }
                int amt = e.isShiftClick() ? 64 : 1;
                double price = getConfig().getDouble("shop." + it.getType().name(), -1);
                if (price < 0) return;
                double total = price * amt;
                if (!take(p.getUniqueId(), total)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(total) + ")"); return; }
                give(p, new ItemStack(it.getType(), amt));
                msg(p, "&aซื้อ " + it.getType().name() + " x" + amt + " ราคา $" + fmt(total));
            }
            case "orders" -> {
                if (slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o)) { openOrders(p); return; }
                if (e.isRightClick() && o.owner.equals(p.getUniqueId())) {
                    orders.remove(o);
                    add(p.getUniqueId(), o.left * o.price);
                    msg(p, "&aยกเลิกออเดอร์ คืนเงิน $" + fmt(o.left * o.price));
                } else if (e.isLeftClick()) {
                    fillOrder(p, o);
                }
                openOrders(p);
            }
            case "rtp" -> {
                World.Environment env = slot == 11 ? World.Environment.NORMAL
                        : slot == 13 ? World.Environment.NETHER
                        : slot == 15 ? World.Environment.THE_END : null;
                if (env == null) return;
                Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); rtp(p, env); });
            }
            case "settings" -> {
                for (int i = 0; i < SETTING_SLOTS.length; i++) {
                    if (SETTING_SLOTS[i] != slot && SETTING_SLOTS[i] + 9 != slot) continue;
                    String key = SETTINGS[i][0];
                    boolean cur = setting(p.getUniqueId(), key, Boolean.parseBoolean(SETTINGS[i][2]));
                    setSetting(p.getUniqueId(), key, !cur);
                    break;
                }
                openSettings(p);
                updateBoard(p);
            }
            case "homes" -> {
                int idx = slot - 10;
                if (idx < 0 || idx >= Math.min(7, getConfig().getInt("homes.max", 3))) return;
                UUID pid = p.getUniqueId();
                if (idx < g.names.size()) {
                    String hname = g.names.get(idx);
                    String path = "homes." + pid + "." + hname;
                    if (e.isShiftClick() && e.isRightClick()) {
                        data.set(path, null);
                        msg(p, "&aลบบ้าน &e" + hname + " &aแล้ว");
                        openHomes(p);
                        return;
                    }
                    Location hl = data.getLocation(path);
                    if (hl == null) { openHomes(p); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(hl);
                        msg(p, "&aวาปไปบ้าน &e" + hname);
                    });
                } else {
                    String nn = nextHomeName(pid);
                    data.set("homes." + pid + "." + nn, p.getLocation());
                    msg(p, "&aตั้งบ้าน &e" + nn + " &aแล้ว");
                    openHomes(p);
                }
            }
            case "shardshop" -> {
                Integer sidx = g.slotIdx.get(slot);
                if (sidx == null) return;
                long price = g.prices.get(sidx);
                UUID pid = p.getUniqueId();
                long have = shards.getOrDefault(pid, 0L);
                if (have < price) { msg(p, "&cShards ไม่พอ (ต้องใช้ " + fmt(price) + ")"); return; }
                shards.put(pid, have - price);
                for (ItemStack gi : g.goods.get(sidx)) give(p, gi.clone());
                msg(p, "&aซื้อสำเร็จ! ใช้ &d" + fmt(price) + " Shards");
                openShardShop(p);
            }
            case "spawner" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page + 1); return; }
                if (slot == 47) {
                    double total = 0;
                    for (Map.Entry<Material, Long> en : sd.items.entrySet()) total += en.getValue() * sellPrice(en.getKey());
                    if (total <= 0) { msg(p, "&cไม่มีของให้ขาย"); return; }
                    sd.items.clear();
                    add(p.getUniqueId(), total);
                    msg(p, "&aขายของในสปอว์นเนอร์ ได้ &e$" + fmt(total));
                    openSpawner(p, sd, 0);
                    return;
                }
                if (slot == 49) {
                    if (sd.xp > 0) {
                        p.giveExp((int) Math.min(Integer.MAX_VALUE, sd.xp));
                        msg(p, "&aรับ XP " + fmt(sd.xp));
                        sd.xp = 0;
                    }
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot == 51) {
                    for (Material m : new ArrayList<>(g.mats)) takeFromSpawner(p, sd, m, Long.MAX_VALUE);
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    Material m = g.mats.get(slot);
                    takeFromSpawner(p, sd, m, e.isShiftClick() ? Long.MAX_VALUE : m.getMaxStackSize());
                    openSpawner(p, sd, g.page);
                }
            }
            case "ah" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openAh(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openAh(p, g.page + 1); return; }
                if (slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAh(p, g.page); return; }
                if (e.isRightClick() && l.seller.equals(p.getUniqueId())) {
                    listings.remove(l);
                    give(p, l.item.clone());
                    msg(p, "&eยกเลิกการขายแล้ว ได้ของคืน");
                } else if (e.isLeftClick()) {
                    buyListing(p, l);
                }
                openAh(p, g.page);
            }
        }
    }

    // ---------- /rtp ----------
    void rtpCmd(Player p, String[] a) {
        if (a.length == 0) { openRtp(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "overworld", "ow", "world", "normal" -> rtp(p, World.Environment.NORMAL);
            case "nether", "hell" -> rtp(p, World.Environment.NETHER);
            case "end", "the_end" -> rtp(p, World.Environment.THE_END);
            default -> openRtp(p);
        }
    }

    void openRtp(Player p) {
        Gui g = new Gui("rtp");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lRTP - เลือกมิติ"));
        g.inv.setItem(11, item(Material.GRASS_BLOCK, "&aโอเวอร์เวิลด์", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(13, item(Material.NETHERRACK, "&cเนเธอร์ (นรก)", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(15, item(Material.END_STONE, "&dดิ เอนด์", "&7คลิกเพื่อสุ่มวาป"));
        p.openInventory(g.inv);
    }

    World findWorld(World.Environment env) {
        return Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == env).findFirst().orElse(null);
    }

    void rtp(Player p, World.Environment env) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cรออีก " + ((cd - (now - last)) / 1000 + 1) + " วินาที"); return; }
        World w = findWorld(env);
        if (w == null) { msg(p, "&cไม่พบโลกมิตินี้ในเซิร์ฟเวอร์"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eกำลังสุ่มตำแหน่ง...");
        tryRtp(p, w, 0, env == World.Environment.THE_END ? 80 : 20);
    }

    void tryRtp(Player p, World w, int tries, int maxTries) {
        if (tries >= maxTries) { msg(p, "&cหาตำแหน่งปลอดภัยไม่ได้ ลองใหม่อีกครั้ง"); rtpCooldown.remove(p.getUniqueId()); return; }
        String key = switch (w.getEnvironment()) { case NETHER -> "nether"; case THE_END -> "end"; default -> "overworld"; };
        int defMin = switch (key) { case "nether" -> 300; case "end" -> 1200; default -> 500; };
        int defMax = switch (key) { case "nether" -> 2500; case "end" -> 4000; default -> 5000; };
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp." + key + ".max", defMax), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp." + key + ".min", defMin), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            Location loc = findSafe(w, x, z);
            if (loc == null) { tryRtp(p, w, tries + 1, maxTries); return; }
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) msg(p, "&aวาปแล้ว! &7X: " + x + " Z: " + z);
            });
        }));
    }

    Location findSafe(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y >= 33; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (isSafe(b)) return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y < w.getMinHeight()) return null;
        Block b = w.getBlockAt(x, y, z);
        return isSafe(b) ? new Location(w, x + 0.5, y + 1, z + 0.5) : null;
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH,
                 WITHER_ROSE, CHORUS_PLANT, CHORUS_FLOWER, BEDROCK -> { return false; }
            default -> { }
        }
        for (int i = 1; i <= 2; i++) {
            Block a = b.getRelative(0, i, 0);
            Material at = a.getType();
            if (!a.isPassable() || a.isLiquid() || at == Material.FIRE || at == Material.SOUL_FIRE || at == Material.LAVA) return false;
        }
        return true;
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if ((n.equals("pay") || n.equals("tpa") || n.equals("tphere")) && a.length == 1) return names(a[0]);
        if (n.equals("eco")) {
            if (a.length == 1) return List.of("give", "take", "set");
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return List.of("money", "shards", "keyall");
        }
        if (n.equals("rtp") && a.length == 1) return List.of("overworld", "nether", "end");
        if (n.equals("shards")) {
            if (a.length == 1) return List.of("pay");
            if (a.length == 2 && a[0].equalsIgnoreCase("pay")) return names(a[1]);
        }
        if (n.equals("spawner")) {
            if (a.length == 1) return List.of("give", "fill");
            if (a.length == 2 && a[0].equalsIgnoreCase("fill")) return mobs(a[1]);
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                    .filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        if (n.equals("ah") && a.length == 1) return List.of("sell");
        if (n.equals("team")) {
            if (a.length == 1) return List.of("create", "invite", "accept", "leave", "info");
            if (a.length == 2 && a[0].equalsIgnoreCase("invite")) return names(a[1]);
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        return List.of();
    }
}
